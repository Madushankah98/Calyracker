import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export default function ProgressPage() {
  const { data: weightLogs, isLoading: weightLoading } = useQuery({
    queryKey: ["/api/weight-logs"],
    queryFn: () => fetch("/api/weight-logs?limit=10").then(res => res.json()),
  });

  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/achievements"],
  });

  const { data: userData } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  if (weightLoading || achievementsLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-muted rounded animate-pulse"></div>
        <div className="grid lg:grid-cols-2 gap-8">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-6 bg-muted rounded"></div>
              </CardHeader>
              <CardContent>
                <div className="h-32 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const profile = (userData as any)?.profile;
  const latestWeight = weightLogs?.[0];
  const startWeight = weightLogs?.[weightLogs.length - 1] || latestWeight;
  const weightLoss = startWeight && latestWeight ? 
    parseFloat(startWeight.weight) - parseFloat(latestWeight.weight) : 0;

  const trackingStreak = (achievements as any)?.find((a: any) => a.type === 'tracking_streak')?.currentStreak || 0;
  const goalStreak = (achievements as any)?.find((a: any) => a.type === 'goal_streak')?.currentStreak || 0;
  const waterStreak = (achievements as any)?.find((a: any) => a.type === 'water_streak')?.currentStreak || 0;
  const exerciseStreak = (achievements as any)?.find((a: any) => a.type === 'exercise_streak')?.currentStreak || 0;

  const progressToGoal = profile?.goalWeight && latestWeight ?
    Math.abs(weightLoss) / Math.abs(parseFloat(profile.currentWeight) - parseFloat(profile.goalWeight)) * 100 : 0;

  return (
    <div className="space-y-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Progress Tracking</h2>
        <p className="text-muted-foreground">Monitor your journey towards your goals</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Weight Progress Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Weight Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-end justify-between space-x-4 mb-4">
              {(weightLogs as any)?.slice(0, 4).reverse().map((log: any, index: number) => (
                <div key={log.id} className="flex flex-col items-center space-y-2">
                  <div className={`relative ${index === 3 ? 'scale-110' : ''}`}>
                    <div className={`w-3 h-3 rounded-full ${
                      index === 3 ? 'bg-primary border-2 border-white shadow-lg' : 'bg-chart-2'
                    }`}></div>
                    {index < 3 && (
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"></div>
                    )}
                  </div>
                  <div className={`text-xs ${index === 3 ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                    Week {index + 1}
                  </div>
                  <div className="text-xs font-bold text-foreground" data-testid={`text-weight-week-${index}`}>
                    {parseFloat(log.weight).toFixed(1)}kg
                  </div>
                </div>
              ))}
            </div>
            
            {profile?.goalWeight && (
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-semibold text-foreground">Progress to Goal</div>
                      <div className="text-sm text-muted-foreground">
                        Target: {parseFloat(profile.goalWeight).toFixed(1)}kg
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary" data-testid="text-weight-lost">
                        {weightLoss > 0 ? `-${weightLoss.toFixed(1)}kg` : `+${Math.abs(weightLoss).toFixed(1)}kg`}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {profile.goal === 'lose' ? 'Lost so far' : profile.goal === 'gain' ? 'Gained so far' : 'Change'}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Progress value={Math.min(progressToGoal, 100)} className="h-2" />
                    <div className="text-xs text-muted-foreground mt-1" data-testid="text-progress-percent">
                      {Math.round(progressToGoal)}% to goal weight
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>

        {/* Weekly Summary */}
        <div className="space-y-6">
          {/* Weekly Adherence */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Adherence</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-foreground">Calorie Goals Met</span>
                  <span className="text-primary font-medium" data-testid="text-calorie-adherence">6/7 days</span>
                </div>
                <Progress value={86} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-foreground">Water Goals Met</span>
                  <span className="text-chart-2 font-medium" data-testid="text-water-adherence">5/7 days</span>
                </div>
                <Progress value={71} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-foreground">Exercise Goals</span>
                  <span className="text-chart-3 font-medium" data-testid="text-exercise-adherence">4/5 days</span>
                </div>
                <Progress value={80} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Streaks & Motivation */}
          <Card>
            <CardHeader>
              <CardTitle>Motivation Zone</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-primary/10 rounded-lg">
                  <div className="text-3xl mb-2">🔥</div>
                  <div className="font-bold text-foreground" data-testid="text-tracking-streak">
                    {trackingStreak} Days
                  </div>
                  <div className="text-xs text-muted-foreground">Tracking Streak</div>
                </div>
                <div className="text-center p-4 bg-chart-2/10 rounded-lg">
                  <div className="text-3xl mb-2">🎯</div>
                  <div className="font-bold text-foreground" data-testid="text-goal-streak">
                    {goalStreak} Days
                  </div>
                  <div className="text-xs text-muted-foreground">Goal Streak</div>
                </div>
                <div className="text-center p-4 bg-chart-3/10 rounded-lg">
                  <div className="text-3xl mb-2">💧</div>
                  <div className="font-bold text-foreground" data-testid="text-water-streak">
                    {waterStreak} Days
                  </div>
                  <div className="text-xs text-muted-foreground">Hydration Streak</div>
                </div>
                <div className="text-center p-4 bg-chart-4/10 rounded-lg">
                  <div className="text-3xl mb-2">💪</div>
                  <div className="font-bold text-foreground" data-testid="text-exercise-streak">
                    {exerciseStreak} Days
                  </div>
                  <div className="text-xs text-muted-foreground">Exercise Streak</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* BMR/TDEE Info */}
          {profile && (
            <Card>
              <CardHeader>
                <CardTitle>Your Metabolic Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <div className="text-sm text-muted-foreground">BMR (Base Metabolic Rate)</div>
                    <div className="text-xl font-bold text-foreground" data-testid="text-bmr">
                      {Math.round(parseFloat(profile.bmr || '0'))} cal/day
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">Calories at rest</div>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <div className="text-sm text-muted-foreground">TDEE (Total Daily Energy)</div>
                    <div className="text-xl font-bold text-foreground" data-testid="text-tdee">
                      {Math.round(parseFloat(profile.tdee || '0'))} cal/day
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">With activity level</div>
                  </div>
                </div>
                <Card className="mt-4 bg-primary/5 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="font-medium text-foreground">Recommended Daily Intake</div>
                        <div className="text-sm text-muted-foreground">
                          For {profile.goal === 'lose' ? '0.5kg/week loss' : 
                               profile.goal === 'gain' ? '0.5kg/week gain' : 
                               'weight maintenance'}
                        </div>
                      </div>
                      <div className="text-xl font-bold text-primary" data-testid="text-recommended-calories">
                        {Math.round(parseFloat(profile.dailyCalorieTarget || '0'))} cal
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
