import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import MealCard from "@/components/meal-card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, startOfWeek, addDays } from "date-fns";

export default function MealPlan() {
  const [selectedDay, setSelectedDay] = useState(0); // 0 = Monday
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const weekStart = format(startOfWeek(new Date(), { weekStartsOn: 1 }), 'yyyy-MM-dd');

  const { data: mealPlan, isLoading } = useQuery({
    queryKey: ["/api/meal-plan"],
    queryFn: () => fetch(`/api/meal-plan?weekStart=${weekStart}`).then(res => res.json()),
  });

  const generateMealPlanMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/meal-plan/generate", {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plan"] });
      toast({
        title: "New meal plan generated!",
        description: "Your fresh weekly meal plan is ready.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="h-8 bg-muted rounded animate-pulse"></div>
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-40 bg-muted"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-3 bg-muted rounded mb-3"></div>
                <div className="grid grid-cols-2 gap-2">
                  <div className="h-3 bg-muted rounded"></div>
                  <div className="h-3 bg-muted rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const selectedDayMeals = mealPlan?.dailyMeals?.filter((dm: any) => dm.dayOfWeek === selectedDay) || [];
  
  // Calculate daily totals for selected day
  const dailyTotals = selectedDayMeals.reduce((totals: any, dm: any) => {
    const meal = dm.meal;
    if (meal) {
      totals.calories += parseFloat(meal.totalCalories || '0');
      totals.protein += parseFloat(meal.totalProtein || '0');
      totals.carbs += parseFloat(meal.totalCarbs || '0');
      totals.fat += parseFloat(meal.totalFat || '0');
    }
    return totals;
  }, { calories: 0, protein: 0, carbs: 0, fat: 0 });

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Your 7-Day Meal Plan</h2>
          <p className="text-muted-foreground">
            Personalized for {mealPlan ? 'your goals' : 'weight loss'} • {Math.round(dailyTotals.calories || 1800)} cal/day target
          </p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="outline"
            onClick={() => generateMealPlanMutation.mutate()}
            disabled={generateMealPlanMutation.isPending}
            data-testid="button-regenerate-plan"
          >
            {generateMealPlanMutation.isPending ? (
              <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
            ) : (
              <i className="fas fa-refresh mr-2"></i>
            )}
            Regenerate Plan
          </Button>
          <Button data-testid="button-export-plan">
            <i className="fas fa-download mr-2"></i>Export Plan
          </Button>
        </div>
      </div>

      {/* Weekly Navigation */}
      <div className="flex space-x-2 overflow-x-auto pb-2">
        {days.map((day, index) => (
          <Button
            key={day}
            variant={selectedDay === index ? "default" : "outline"}
            onClick={() => setSelectedDay(index)}
            className="whitespace-nowrap"
            data-testid={`button-day-${day.toLowerCase()}`}
          >
            {day.slice(0, 3)}
          </Button>
        ))}
      </div>

      {!mealPlan ? (
        <Card className="text-center p-8">
          <CardContent>
            <div className="w-16 h-16 bg-muted rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-utensils text-muted-foreground text-2xl"></i>
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No Meal Plan Yet</h3>
            <p className="text-muted-foreground mb-6">Generate your first personalized meal plan to get started!</p>
            <Button onClick={() => generateMealPlanMutation.mutate()} data-testid="button-generate-first-plan">
              Generate My Meal Plan
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Daily Totals Banner */}
          <Card className="bg-gradient-to-r from-primary to-chart-2 text-primary-foreground border-0">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold" data-testid="text-daily-calories">
                    {Math.round(dailyTotals.calories)}
                  </div>
                  <div className="text-sm opacity-90">Total Calories</div>
                </div>
                <div>
                  <div className="text-2xl font-bold" data-testid="text-daily-protein">
                    {Math.round(dailyTotals.protein)}g
                  </div>
                  <div className="text-sm opacity-90">Protein</div>
                </div>
                <div>
                  <div className="text-2xl font-bold" data-testid="text-daily-carbs">
                    {Math.round(dailyTotals.carbs)}g
                  </div>
                  <div className="text-sm opacity-90">Carbs</div>
                </div>
                <div>
                  <div className="text-2xl font-bold" data-testid="text-daily-fat">
                    {Math.round(dailyTotals.fat)}g
                  </div>
                  <div className="text-sm opacity-90">Fat</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Meals Grid */}
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
            {selectedDayMeals.map((dailyMeal: any, index: number) => (
              <MealCard 
                key={`${dailyMeal.id}-${index}`}
                meal={dailyMeal.meal}
                mealType={dailyMeal.mealType}
              />
            ))}
          </div>

          {selectedDayMeals.length === 0 && (
            <Card className="text-center p-8">
              <CardContent>
                <div className="text-muted-foreground">No meals planned for {days[selectedDay]}</div>
              </CardContent>
            </Card>
          )}

          {/* Meal Plan Features */}
          <Card>
            <CardHeader>
              <CardTitle>Meal Plan Features</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-3 p-3 bg-primary/5 rounded-lg">
                  <i className="fas fa-shuffle text-primary"></i>
                  <div>
                    <div className="font-medium text-foreground">Randomized Daily</div>
                    <div className="text-xs text-muted-foreground">Fresh variety every week</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-chart-2/5 rounded-lg">
                  <i className="fas fa-heart text-chart-2"></i>
                  <div>
                    <div className="font-medium text-foreground">Allergy Safe</div>
                    <div className="text-xs text-muted-foreground">Respects your restrictions</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-chart-3/5 rounded-lg">
                  <i className="fas fa-balance-scale text-chart-3"></i>
                  <div>
                    <div className="font-medium text-foreground">Macro Balanced</div>
                    <div className="text-xs text-muted-foreground">Optimized for your goal</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
