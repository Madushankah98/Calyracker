// BMR calculation using Mifflin-St Jeor Equation
export function calculateBMR(
  weight: number, // kg
  height: number, // cm
  age: number,
  sex: 'male' | 'female'
): number {
  if (sex === 'male') {
    return (10 * weight) + (6.25 * height) - (5 * age) + 5;
  } else {
    return (10 * weight) + (6.25 * height) - (5 * age) - 161;
  }
}

// TDEE calculation with activity multipliers
export function calculateTDEE(bmr: number, activityLevel: string): number {
  const activityMultipliers: Record<string, number> = {
    'sedentary': 1.2,
    'lightly_active': 1.375,
    'moderately_active': 1.55,
    'very_active': 1.725,
    'extremely_active': 1.9,
  };

  const activityKey = activityLevel.toLowerCase().replace(/\s+/g, '_').replace(/[()]/g, '');
  const multiplier = activityMultipliers[activityKey] || 1.375;
  
  return bmr * multiplier;
}

// Calculate daily calorie target based on goal
export function calculateDailyCalorieTarget(tdee: number, goal: string): number {
  switch (goal) {
    case 'lose':
      return tdee - 500; // 0.5kg per week loss
    case 'gain':
      return tdee + 500; // 0.5kg per week gain
    case 'maintain':
    default:
      return tdee;
  }
}

// Calculate macro targets
export function calculateMacroTargets(dailyCalories: number, goal: string) {
  let proteinPercent: number;
  let carbPercent: number;
  let fatPercent: number;

  switch (goal) {
    case 'lose':
      // Higher protein for weight loss
      proteinPercent = 0.35;
      carbPercent = 0.35;
      fatPercent = 0.30;
      break;
    case 'gain':
      // More carbs for weight gain
      proteinPercent = 0.25;
      carbPercent = 0.45;
      fatPercent = 0.30;
      break;
    case 'maintain':
    default:
      // Balanced macros for maintenance
      proteinPercent = 0.30;
      carbPercent = 0.40;
      fatPercent = 0.30;
      break;
  }

  return {
    protein: (dailyCalories * proteinPercent) / 4, // 4 calories per gram
    carbs: (dailyCalories * carbPercent) / 4, // 4 calories per gram
    fat: (dailyCalories * fatPercent) / 9, // 9 calories per gram
  };
}

// Calculate progress percentage towards goal weight
export function calculateWeightProgress(
  startWeight: number,
  currentWeight: number,
  goalWeight: number
): number {
  const totalWeightChange = Math.abs(goalWeight - startWeight);
  const currentWeightChange = Math.abs(currentWeight - startWeight);
  
  if (totalWeightChange === 0) return 100;
  
  return Math.min((currentWeightChange / totalWeightChange) * 100, 100);
}

// Water intake recommendations (glasses per day)
export const RECOMMENDED_WATER_GLASSES = 8;

// Calculate BMI
export function calculateBMI(weight: number, height: number): number {
  const heightInMeters = height / 100;
  return weight / (heightInMeters * heightInMeters);
}

// Get BMI category
export function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal weight';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

// Calculate calorie deficit/surplus needed per day for goal
export function calculateCalorieAdjustment(goal: string): number {
  switch (goal) {
    case 'lose':
      return -500; // 500 calorie deficit
    case 'gain':
      return 500; // 500 calorie surplus
    case 'maintain':
    default:
      return 0;
  }
}
