import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertUserProfileSchema,
  insertFoodLogSchema,
  insertWaterLogSchema,
  insertWeightLogSchema,
  insertExerciseLogSchema,
} from "@shared/schema";
import { z } from "zod";
import { format, startOfWeek, addDays } from "date-fns";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const profile = await storage.getUserProfile(userId);
      res.json({ user, profile });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User profile routes
  app.post('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = insertUserProfileSchema.parse({
        ...req.body,
        userId,
      });
      
      // Calculate BMR and TDEE
      const { age, sex, height, currentWeight, activityLevel, goal } = profileData;
      
      // Mifflin-St Jeor equation
      const heightNum = parseFloat(height);
      const weightNum = parseFloat(currentWeight);
      const bmr = sex === 'male' 
        ? (10 * weightNum) + (6.25 * heightNum) - (5 * age) + 5
        : (10 * weightNum) + (6.25 * heightNum) - (5 * age) - 161;
      
      // Activity multipliers
      const activityMultipliers = {
        'sedentary': 1.2,
        'lightly_active': 1.375,
        'moderately_active': 1.55,
        'very_active': 1.725,
        'extremely_active': 1.9,
      };
      
      const activityKey = activityLevel.toLowerCase().replace(/\s+/g, '_').replace(/[()]/g, '');
      const multiplier = activityMultipliers[activityKey as keyof typeof activityMultipliers] || 1.375;
      const tdee = bmr * multiplier;
      
      // Calorie adjustment based on goal
      let dailyCalorieTarget = tdee;
      if (goal === 'lose') {
        dailyCalorieTarget = tdee - 500; // 0.5kg per week loss
      } else if (goal === 'gain') {
        dailyCalorieTarget = tdee + 500; // 0.5kg per week gain
      }
      
      // Macro targets (40% carbs, 30% protein, 30% fat for weight loss)
      const proteinTarget = goal === 'lose' ? (dailyCalorieTarget * 0.35) / 4 : (dailyCalorieTarget * 0.30) / 4;
      const carbTarget = goal === 'lose' ? (dailyCalorieTarget * 0.35) / 4 : (dailyCalorieTarget * 0.40) / 4;
      const fatTarget = goal === 'lose' ? (dailyCalorieTarget * 0.30) / 9 : (dailyCalorieTarget * 0.30) / 9;
      
      const completeProfile = {
        ...profileData,
        bmr: bmr.toString(),
        tdee: tdee.toString(),
        dailyCalorieTarget: dailyCalorieTarget.toString(),
        proteinTarget: proteinTarget.toString(),
        carbTarget: carbTarget.toString(),
        fatTarget: fatTarget.toString(),
      };
      
      const profile = await storage.createUserProfile(completeProfile);
      res.json(profile);
    } catch (error) {
      console.error("Error creating profile:", error);
      res.status(400).json({ message: "Invalid profile data" });
    }
  });

  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updates = req.body;
      const profile = await storage.updateUserProfile(userId, updates);
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Meal plan routes
  app.get('/api/meal-plan', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const weekStart = req.query.weekStart as string;
      
      const mealPlan = await storage.getUserMealPlan(userId, weekStart);
      if (!mealPlan) {
        return res.json(null);
      }
      
      const dailyMeals = await storage.getDailyMeals(mealPlan.id);
      
      // Group by day and include meal details
      const mealPlanWithMeals = {
        ...mealPlan,
        dailyMeals: await Promise.all(
          dailyMeals.map(async (dm) => {
            const meal = await storage.getMeal(dm.mealId);
            return { ...dm, meal };
          })
        ),
      };
      
      res.json(mealPlanWithMeals);
    } catch (error) {
      console.error("Error fetching meal plan:", error);
      res.status(500).json({ message: "Failed to fetch meal plan" });
    }
  });

  app.post('/api/meal-plan/generate', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);
      
      if (!profile) {
        return res.status(400).json({ message: "User profile not found" });
      }
      
      // Get current week start (Monday)
      const now = new Date();
      const weekStart = startOfWeek(now, { weekStartsOn: 1 });
      const weekStartStr = format(weekStart, 'yyyy-MM-dd');
      
      // Create new meal plan
      const mealPlan = await storage.createMealPlan({
        userId,
        weekStartDate: weekStartStr,
        isActive: true,
      });
      
      // Generate randomized meals for each day
      const mealTypes = ['breakfast', 'morning_snack', 'lunch', 'afternoon_snack', 'dinner'];
      const dietaryTags = profile.dietaryPreferences || [];
      
      for (let day = 0; day < 7; day++) {
        for (let i = 0; i < mealTypes.length; i++) {
          const mealType = mealTypes[i];
          const availableMeals = await storage.getMealsByType(mealType);
          
          // Filter by dietary preferences
          let filteredMeals = availableMeals;
          if (dietaryTags.length > 0) {
            filteredMeals = await storage.getMealsByDietaryTags(dietaryTags);
            filteredMeals = filteredMeals.filter(meal => meal.mealType === mealType);
          }
          
          if (filteredMeals.length === 0) {
            filteredMeals = availableMeals; // Fallback to all meals
          }
          
          // Select random meal
          const randomMeal = filteredMeals[Math.floor(Math.random() * filteredMeals.length)];
          
          if (randomMeal) {
            await storage.createDailyMeal(randomMeal.id, mealPlan.id, day, mealType, i);
          }
        }
      }
      
      res.json(mealPlan);
    } catch (error) {
      console.error("Error generating meal plan:", error);
      res.status(500).json({ message: "Failed to generate meal plan" });
    }
  });

  // Food logging routes
  app.get('/api/food-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.query.date as string;
      const logs = await storage.getFoodLogs(userId, date);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching food logs:", error);
      res.status(500).json({ message: "Failed to fetch food logs" });
    }
  });

  app.post('/api/food-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logData = insertFoodLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.createFoodLog(logData);
      res.json(log);
    } catch (error) {
      console.error("Error creating food log:", error);
      res.status(400).json({ message: "Invalid food log data" });
    }
  });

  // Water tracking routes
  app.get('/api/water-log/:date', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.params.date;
      const log = await storage.getWaterLog(userId, date);
      res.json(log || { glasses: 0 });
    } catch (error) {
      console.error("Error fetching water log:", error);
      res.status(500).json({ message: "Failed to fetch water log" });
    }
  });

  app.post('/api/water-log', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logData = insertWaterLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.upsertWaterLog(logData);
      res.json(log);
    } catch (error) {
      console.error("Error updating water log:", error);
      res.status(400).json({ message: "Invalid water log data" });
    }
  });

  // Weight tracking routes
  app.get('/api/weight-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const logs = await storage.getWeightLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching weight logs:", error);
      res.status(500).json({ message: "Failed to fetch weight logs" });
    }
  });

  app.post('/api/weight-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logData = insertWeightLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.createWeightLog(logData);
      res.json(log);
    } catch (error) {
      console.error("Error creating weight log:", error);
      res.status(400).json({ message: "Invalid weight log data" });
    }
  });

  // Exercise tracking routes
  app.get('/api/exercise-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const date = req.query.date as string;
      const logs = await storage.getExerciseLogs(userId, date);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching exercise logs:", error);
      res.status(500).json({ message: "Failed to fetch exercise logs" });
    }
  });

  app.post('/api/exercise-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const logData = insertExerciseLogSchema.parse({
        ...req.body,
        userId,
      });
      
      const log = await storage.createExerciseLog(logData);
      res.json(log);
    } catch (error) {
      console.error("Error creating exercise log:", error);
      res.status(400).json({ message: "Invalid exercise log data" });
    }
  });

  // Achievement routes
  app.get('/api/achievements', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const achievements = await storage.getUserAchievements(userId);
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  // Meals routes
  app.get('/api/meals', async (req, res) => {
    try {
      const meals = await storage.getMeals();
      res.json(meals);
    } catch (error) {
      console.error("Error fetching meals:", error);
      res.status(500).json({ message: "Failed to fetch meals" });
    }
  });

  app.get('/api/meals/:id', async (req, res) => {
    try {
      const meal = await storage.getMeal(req.params.id);
      if (!meal) {
        return res.status(404).json({ message: "Meal not found" });
      }
      res.json(meal);
    } catch (error) {
      console.error("Error fetching meal:", error);
      res.status(500).json({ message: "Failed to fetch meal" });
    }
  });

  // Dashboard analytics route
  app.get('/api/dashboard', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const today = format(new Date(), 'yyyy-MM-dd');
      
      // Get today's food logs
      const foodLogs = await storage.getFoodLogs(userId, today);
      const totalCalories = foodLogs.reduce((sum, log) => sum + parseFloat(log.calories), 0);
      const totalProtein = foodLogs.reduce((sum, log) => sum + parseFloat(log.protein || '0'), 0);
      const totalCarbs = foodLogs.reduce((sum, log) => sum + parseFloat(log.carbs || '0'), 0);
      const totalFat = foodLogs.reduce((sum, log) => sum + parseFloat(log.fat || '0'), 0);
      
      // Get water log
      const waterLog = await storage.getWaterLog(userId, today);
      
      // Get latest weight
      const latestWeight = await storage.getLatestWeight(userId);
      
      // Get achievements/streaks
      const achievements = await storage.getUserAchievements(userId);
      
      // Get user profile for targets
      const profile = await storage.getUserProfile(userId);
      
      res.json({
        dailyTotals: {
          calories: totalCalories,
          protein: totalProtein,
          carbs: totalCarbs,
          fat: totalFat,
        },
        waterGlasses: waterLog?.glasses || 0,
        currentWeight: latestWeight?.weight || profile?.currentWeight || 0,
        achievements,
        profile,
      });
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Seed data route (for development)
  app.post('/api/seed', async (req, res) => {
    try {
      // Seed some basic food items and meals
      const sampleFoods = [
        {
          name: "Greek Yogurt",
          caloriesPer100g: "59",
          proteinPer100g: "10.0",
          carbsPer100g: "3.6",
          fatPer100g: "0.4",
          category: "dairy",
        },
        {
          name: "Chicken Breast",
          caloriesPer100g: "165",
          proteinPer100g: "31.0",
          carbsPer100g: "0.0",
          fatPer100g: "3.6",
          category: "protein",
        },
        {
          name: "Quinoa",
          caloriesPer100g: "120",
          proteinPer100g: "4.4",
          carbsPer100g: "22.0",
          fatPer100g: "1.9",
          category: "grains",
        },
      ];

      for (const food of sampleFoods) {
        await storage.createFoodItem(food);
      }

      const sampleMeals = [
        {
          name: "Berry Protein Bowl",
          description: "Greek yogurt with mixed berries, granola, and almonds",
          mealType: "breakfast",
          totalCalories: "320",
          totalProtein: "28",
          totalCarbs: "35",
          totalFat: "12",
          dietaryTags: ["vegetarian"],
          imageUrl: "https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        },
        {
          name: "Mediterranean Chicken Bowl",
          description: "Grilled chicken, quinoa, mixed greens, feta, olives",
          mealType: "lunch",
          totalCalories: "485",
          totalProtein: "42",
          totalCarbs: "38",
          totalFat: "18",
          dietaryTags: ["gluten-free"],
          imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        },
        {
          name: "Herb-Crusted Salmon",
          description: "Baked salmon, quinoa pilaf, roasted asparagus",
          mealType: "dinner",
          totalCalories: "520",
          totalProtein: "38",
          totalCarbs: "45",
          totalFat: "22",
          dietaryTags: ["gluten-free"],
          imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        },
        {
          name: "Apple & Almond Butter",
          description: "Sliced apple with 2 tbsp almond butter",
          mealType: "morning_snack",
          totalCalories: "245",
          totalProtein: "8",
          totalCarbs: "25",
          totalFat: "16",
          dietaryTags: ["vegetarian", "vegan", "gluten-free"],
          imageUrl: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        },
        {
          name: "Greek Yogurt & Honey",
          description: "Plain Greek yogurt, honey drizzle, chopped walnuts",
          mealType: "afternoon_snack",
          totalCalories: "190",
          totalProtein: "15",
          totalCarbs: "18",
          totalFat: "8",
          dietaryTags: ["vegetarian"],
          imageUrl: "https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
        },
      ];

      for (const meal of sampleMeals) {
        await storage.createMeal(meal);
      }

      res.json({ message: "Seed data created successfully" });
    } catch (error) {
      console.error("Error seeding data:", error);
      res.status(500).json({ message: "Failed to seed data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
