import { type Meal } from "@shared/schema";

// Sample meal data for development/fallback
export const SAMPLE_MEALS: Partial<Meal>[] = [
  {
    name: "Berry Protein Bowl",
    description: "Greek yogurt with mixed berries, granola, and almonds",
    mealType: "breakfast",
    totalCalories: "320",
    totalProtein: "28",
    totalCarbs: "35",
    totalFat: "12",
    dietaryTags: ["vegetarian"],
    imageUrl: "https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
  {
    name: "Mediterranean Chicken Bowl",
    description: "Grilled chicken, quinoa, mixed greens, feta, olives",
    mealType: "lunch",
    totalCalories: "485",
    totalProtein: "42",
    totalCarbs: "38",
    totalFat: "18",
    dietaryTags: ["gluten-free"],
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
  {
    name: "Herb-Crusted Salmon",
    description: "Baked salmon, quinoa pilaf, roasted asparagus",
    mealType: "dinner",
    totalCalories: "520",
    totalProtein: "38",
    totalCarbs: "45",
    totalFat: "22",
    dietaryTags: ["gluten-free"],
    imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
];

// Meal type configurations
export const MEAL_TYPES = {
  breakfast: {
    label: "Breakfast",
    color: "bg-primary/10 text-primary",
    icon: "fas fa-sun",
    order: 0,
  },
  morning_snack: {
    label: "Morning Snack",
    color: "bg-chart-3/10 text-chart-3",
    icon: "fas fa-apple-alt",
    order: 1,
  },
  lunch: {
    label: "Lunch",
    color: "bg-chart-2/10 text-chart-2",
    icon: "fas fa-utensils",
    order: 2,
  },
  afternoon_snack: {
    label: "Afternoon Snack",
    color: "bg-chart-3/10 text-chart-3",
    icon: "fas fa-cookie-bite",
    order: 3,
  },
  dinner: {
    label: "Dinner",
    color: "bg-chart-4/10 text-chart-4",
    icon: "fas fa-moon",
    order: 4,
  },
} as const;

// Dietary preferences and their compatibility
export const DIETARY_PREFERENCES = {
  vegetarian: {
    label: "Vegetarian",
    excludes: ["meat", "fish", "poultry"],
    color: "bg-green-100 text-green-800",
  },
  vegan: {
    label: "Vegan",
    excludes: ["meat", "fish", "poultry", "dairy", "eggs"],
    color: "bg-green-100 text-green-800",
  },
  "gluten-free": {
    label: "Gluten-Free",
    excludes: ["gluten", "wheat"],
    color: "bg-yellow-100 text-yellow-800",
  },
  keto: {
    label: "Keto",
    macros: { carbs: "max-20g", fat: "70-80%", protein: "15-25%" },
    color: "bg-purple-100 text-purple-800",
  },
  paleo: {
    label: "Paleo",
    excludes: ["grains", "legumes", "dairy", "processed"],
    color: "bg-orange-100 text-orange-800",
  },
} as const;

// Generate meal plan structure for a week
export function generateWeekStructure() {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const mealTypes = Object.keys(MEAL_TYPES);
  
  return days.map((day, dayIndex) => ({
    day,
    dayIndex,
    meals: mealTypes.map((mealType, mealIndex) => ({
      mealType,
      order: mealIndex,
      meal: null,
    })),
  }));
}

// Filter meals by dietary preferences
export function filterMealsByDiet(meals: Meal[], dietaryPreferences: string[]): Meal[] {
  if (!dietaryPreferences.length) return meals;
  
  return meals.filter(meal => {
    if (!meal.dietaryTags) return false;
    
    // Check if meal has at least one matching dietary tag
    return dietaryPreferences.some(pref => 
      meal.dietaryTags?.includes(pref)
    );
  });
}

// Calculate total nutrition for a day's meals
export function calculateDayTotals(meals: (Meal | null | undefined)[]): {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
} {
  return meals.reduce(
    (totals, meal) => {
      if (!meal) return totals;
      
      return {
        calories: totals.calories + parseFloat(meal.totalCalories || '0'),
        protein: totals.protein + parseFloat(meal.totalProtein || '0'),
        carbs: totals.carbs + parseFloat(meal.totalCarbs || '0'),
        fat: totals.fat + parseFloat(meal.totalFat || '0'),
      };
    },
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );
}

// Get random meals for meal plan generation
export function getRandomMealsForType(
  meals: Meal[], 
  mealType: string, 
  count: number = 1
): Meal[] {
  const filteredMeals = meals.filter(meal => meal.mealType === mealType);
  const shuffled = [...filteredMeals].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

// Format meal type for display
export function formatMealType(mealType: string): string {
  return MEAL_TYPES[mealType as keyof typeof MEAL_TYPES]?.label || 
         mealType.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
}

// Get meal type color
export function getMealTypeColor(mealType: string): string {
  return MEAL_TYPES[mealType as keyof typeof MEAL_TYPES]?.color || 
         'bg-muted text-muted-foreground';
}

// Validate meal nutrition data
export function validateMealNutrition(meal: Partial<Meal>): boolean {
  const requiredFields = ['totalCalories', 'totalProtein', 'totalCarbs', 'totalFat'];
  return requiredFields.every(field => {
    const value = meal[field as keyof Meal];
    return value && !isNaN(parseFloat(value as string)) && parseFloat(value as string) >= 0;
  });
}
