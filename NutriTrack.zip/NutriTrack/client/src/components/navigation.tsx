import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { useAuth } from "@/hooks/useAuth";

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const { theme, setTheme } = useTheme();
  const { user } = useAuth();

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const getInitials = () => {
    if ((user as any)?.user?.firstName && (user as any)?.user?.lastName) {
      return `${(user as any).user.firstName[0]}${(user as any).user.lastName[0]}`.toUpperCase();
    }
    if ((user as any)?.user?.email) {
      return (user as any).user.email.slice(0, 2).toUpperCase();
    }
    return "U";
  };

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "fas fa-chart-line" },
    { id: "meals", label: "Meal Plan", icon: "fas fa-utensils" },
    { id: "progress", label: "Progress", icon: "fas fa-trophy" },
    { id: "export", label: "Export", icon: "fas fa-download" },
  ];

  return (
    <>
      {/* Header */}
      <header className="bg-card border-b border-border p-4 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <i className="fas fa-leaf text-primary-foreground"></i>
            </div>
            <h1 className="text-xl font-bold text-foreground">NutriTrack</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-secondary hover:bg-accent transition-colors"
              data-testid="button-toggle-theme"
            >
              <i className={`fas ${theme === "dark" ? "fa-sun" : "fa-moon"} text-secondary-foreground`}></i>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.href = '/api/logout'}
              className="p-2 rounded-lg bg-secondary hover:bg-accent transition-colors"
              data-testid="button-logout"
            >
              <i className="fas fa-sign-out-alt text-secondary-foreground"></i>
            </Button>
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground text-sm font-medium" data-testid="text-user-initials">
                {getInitials()}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-card border-b border-border">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex space-x-1 overflow-x-auto">
            {tabs.map((tab) => (
              <Button
                key={tab.id}
                variant="ghost"
                onClick={() => onTabChange(tab.id)}
                className={`px-6 py-3 font-medium transition-colors whitespace-nowrap border-b-2 rounded-none ${
                  activeTab === tab.id
                    ? "text-primary border-primary"
                    : "text-muted-foreground border-transparent hover:text-foreground hover:border-primary"
                }`}
                data-testid={`button-tab-${tab.id}`}
              >
                <i className={`${tab.icon} mr-2`}></i>
                {tab.label}
              </Button>
            ))}
          </div>
        </div>
      </nav>
    </>
  );
}
