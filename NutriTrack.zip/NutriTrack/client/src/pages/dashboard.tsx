import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import ProgressRing from "@/components/progress-ring";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: waterLog } = useQuery({
    queryKey: ["/api/water-log", today],
  });

  const addWaterMutation = useMutation({
    mutationFn: async () => {
      const currentGlasses = (waterLog as any)?.glasses || 0;
      return await apiRequest("POST", "/api/water-log", {
        glasses: currentGlasses + 1,
        date: today,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/water-log"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Water logged!",
        description: "Keep up the good hydration!",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-8 bg-muted rounded mb-2"></div>
                <div className="h-4 bg-muted rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const profile = (dashboardData as any)?.profile;
  const dailyTotals = (dashboardData as any)?.dailyTotals || {};
  const currentWeight = (dashboardData as any)?.currentWeight || 0;
  const waterGlasses = (waterLog as any)?.glasses || 0;
  const achievements = (dashboardData as any)?.achievements || [];

  const calorieProgress = profile ? (dailyTotals.calories / parseFloat(profile.dailyCalorieTarget)) * 100 : 0;
  const proteinProgress = profile ? (dailyTotals.protein / parseFloat(profile.proteinTarget)) * 100 : 0;
  const carbProgress = profile ? (dailyTotals.carbs / parseFloat(profile.carbTarget)) * 100 : 0;
  const fatProgress = profile ? (dailyTotals.fat / parseFloat(profile.fatTarget)) * 100 : 0;

  const trackingStreak = achievements.find((a: any) => a.type === 'tracking_streak')?.currentStreak || 0;

  return (
    <div className="space-y-8">
      {/* Quick Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-primary" data-testid="text-calories-consumed">
              {Math.round(dailyTotals.calories || 0)}
            </div>
            <div className="text-sm text-muted-foreground">Calories Today</div>
            <div className="text-xs text-muted-foreground mt-1">
              of <span data-testid="text-calories-target">{profile ? Math.round(parseFloat(profile.dailyCalorieTarget)) : 0}</span> goal
            </div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-chart-2" data-testid="text-current-weight">
              {parseFloat(currentWeight.toString()).toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">Current Weight</div>
            <div className="text-xs text-primary mt-1">
              {profile && currentWeight < parseFloat(profile.currentWeight) ? 
                `-${(parseFloat(profile.currentWeight) - currentWeight).toFixed(1)}kg from start` :
                'Track your progress'
              }
            </div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-chart-3" data-testid="text-streak">
              {trackingStreak}
            </div>
            <div className="text-sm text-muted-foreground">Day Streak</div>
            <div className="text-xs text-muted-foreground mt-1">🔥 Keep it up!</div>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-chart-1" data-testid="text-water-glasses">
              {waterGlasses}
            </div>
            <div className="text-sm text-muted-foreground">Glasses of Water</div>
            <div className="text-xs text-muted-foreground mt-1">of 8 goal</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column - Progress Rings */}
        <div className="lg:col-span-1 space-y-6">
          {/* Daily Progress */}
          <Card>
            <CardHeader>
              <CardTitle>Today's Progress</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Calories Progress Ring */}
              <div className="flex items-center space-x-4">
                <ProgressRing 
                  progress={Math.min(calorieProgress, 100)} 
                  size={80}
                  strokeWidth={8}
                  className="text-primary"
                />
                <div>
                  <div className="font-semibold text-foreground">Calories</div>
                  <div className="text-sm text-muted-foreground">
                    {Math.round(dailyTotals.calories || 0)} / {profile ? Math.round(parseFloat(profile.dailyCalorieTarget)) : 0}
                  </div>
                  <div className="text-xs text-primary">
                    {profile ? Math.round(parseFloat(profile.dailyCalorieTarget) - (dailyTotals.calories || 0)) : 0} remaining
                  </div>
                </div>
              </div>

              {/* Macros Progress */}
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-foreground">Protein</span>
                    <span className="text-muted-foreground">
                      {Math.round(dailyTotals.protein || 0)}g / {profile ? Math.round(parseFloat(profile.proteinTarget)) : 0}g
                    </span>
                  </div>
                  <Progress value={Math.min(proteinProgress, 100)} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-foreground">Carbs</span>
                    <span className="text-muted-foreground">
                      {Math.round(dailyTotals.carbs || 0)}g / {profile ? Math.round(parseFloat(profile.carbTarget)) : 0}g
                    </span>
                  </div>
                  <Progress value={Math.min(carbProgress, 100)} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-foreground">Fat</span>
                    <span className="text-muted-foreground">
                      {Math.round(dailyTotals.fat || 0)}g / {profile ? Math.round(parseFloat(profile.fatTarget)) : 0}g
                    </span>
                  </div>
                  <Progress value={Math.min(fatProgress, 100)} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Water Tracking */}
          <Card>
            <CardHeader>
              <CardTitle>Hydration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center mb-4">
                <div className="grid grid-cols-4 gap-2">
                  {[...Array(8)].map((_, i) => (
                    <div 
                      key={i}
                      className={`w-8 h-10 border-2 rounded-b-lg ${
                        i < waterGlasses 
                          ? 'border-chart-2 bg-chart-2/80' 
                          : 'border-border bg-muted/20'
                      }`}
                      data-testid={`water-glass-${i}`}
                    />
                  ))}
                </div>
              </div>
              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-3">
                  {waterGlasses} of 8 glasses
                </div>
                <Button
                  onClick={() => addWaterMutation.mutate()}
                  disabled={addWaterMutation.isPending || waterGlasses >= 8}
                  className="bg-chart-2 text-white hover:bg-chart-2/90"
                  data-testid="button-add-water"
                >
                  <i className="fas fa-plus mr-1"></i>Add Glass
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" className="p-3 h-auto flex flex-col" data-testid="button-log-food">
                  <i className="fas fa-plus mb-1 text-lg"></i>
                  Log Food
                </Button>
                <Button 
                  variant="outline" 
                  className="p-3 h-auto flex flex-col"
                  onClick={() => addWaterMutation.mutate()}
                  disabled={waterGlasses >= 8}
                  data-testid="button-add-water-quick"
                >
                  <i className="fas fa-tint mb-1 text-lg"></i>
                  Add Water
                </Button>
                <Button variant="outline" className="p-3 h-auto flex flex-col" data-testid="button-weigh-in">
                  <i className="fas fa-weight mb-1 text-lg"></i>
                  Weigh In
                </Button>
                <Button variant="outline" className="p-3 h-auto flex flex-col" data-testid="button-add-exercise">
                  <i className="fas fa-dumbbell mb-1 text-lg"></i>
                  Exercise
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Center Column - Charts and Meals */}
        <div className="lg:col-span-2 space-y-6">
          {/* Weekly Overview Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Calorie Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-end justify-between space-x-2">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Today'].map((day, index) => {
                  const heights = [60, 85, 72, 95, 110, 78, 69];
                  const isOverGoal = heights[index] > 100;
                  return (
                    <div key={day} className="flex flex-col items-center space-y-2">
                      <div 
                        className={`w-8 rounded-t transition-all duration-500 ${
                          isOverGoal ? 'bg-chart-3' : 'bg-primary'
                        }`}
                        style={{ height: `${Math.min(heights[index], 120)}%` }}
                      />
                      <div className={`text-xs ${day === 'Today' ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                        {day}
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="flex justify-center mt-4 space-x-4 text-xs">
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 bg-primary rounded"></div>
                  <span className="text-muted-foreground">Within Goal</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-3 h-3 bg-chart-3 rounded"></div>
                  <span className="text-muted-foreground">Over Goal</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Today's Meals Quick View */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Today's Meals</CardTitle>
                <Button variant="ghost" size="sm" data-testid="button-view-full-plan">
                  View Full Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50">
                  <img 
                    src="https://images.unsplash.com/photo-1511690743698-d9d85f2fbf38?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80" 
                    alt="Breakfast bowl" 
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-foreground">Berry Protein Bowl</div>
                    <div className="text-sm text-muted-foreground">Breakfast • 320 cal</div>
                  </div>
                  <div className="text-primary text-sm font-medium">✓</div>
                </div>
                
                <div className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50">
                  <img 
                    src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80" 
                    alt="Chicken salad" 
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-foreground">Mediterranean Chicken Bowl</div>
                    <div className="text-sm text-muted-foreground">Lunch • 485 cal</div>
                  </div>
                  <div className="text-primary text-sm font-medium">✓</div>
                </div>

                <div className="flex items-center space-x-4 p-3 rounded-lg border-2 border-dashed border-primary/30">
                  <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                    <i className="fas fa-clock text-muted-foreground"></i>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-foreground">Herb-Crusted Salmon</div>
                    <div className="text-sm text-muted-foreground">Dinner • 520 cal</div>
                  </div>
                  <Button size="sm" variant="ghost" data-testid="button-log-meal">
                    Log
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
