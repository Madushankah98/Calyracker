import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { type Meal } from "@shared/schema";

interface MealCardProps {
  meal?: Meal | null;
  mealType: string;
}

export default function MealCard({ meal, mealType }: MealCardProps) {
  if (!meal) {
    return (
      <Card className="transition-all duration-200 hover:shadow-lg">
        <div className="h-40 bg-muted flex items-center justify-center">
          <i className="fas fa-utensils text-muted-foreground text-2xl"></i>
        </div>
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-semibold text-foreground">No meal planned</h4>
            <Badge variant="outline" className="text-xs">
              {mealType.replace('_', ' ')}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">Add a meal to your plan</p>
        </CardContent>
      </Card>
    );
  }

  const getMealTypeColor = (type: string) => {
    switch (type) {
      case 'breakfast':
        return 'bg-primary/10 text-primary';
      case 'lunch':
        return 'bg-chart-2/10 text-chart-2';
      case 'dinner':
        return 'bg-chart-4/10 text-chart-4';
      case 'morning_snack':
      case 'afternoon_snack':
        return 'bg-chart-3/10 text-chart-3';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatMealType = (type: string) => {
    return type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <Card className="transition-all duration-200 hover:shadow-lg hover:-translate-y-1">
      {meal.imageUrl ? (
        <img 
          src={meal.imageUrl} 
          alt={meal.name} 
          className="w-full h-40 object-cover rounded-t-lg"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.style.display = 'none';
            target.nextElementSibling?.classList.remove('hidden');
          }}
        />
      ) : null}
      <div className={`h-40 bg-muted flex items-center justify-center rounded-t-lg ${meal.imageUrl ? 'hidden' : ''}`}>
        <i className="fas fa-utensils text-muted-foreground text-2xl"></i>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h4 className="font-semibold text-foreground" data-testid={`text-meal-name-${meal.id}`}>
            {meal.name}
          </h4>
          <Badge className={`text-xs ${getMealTypeColor(mealType)}`}>
            {formatMealType(mealType)}
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground mb-3" data-testid={`text-meal-description-${meal.id}`}>
          {meal.description || "Delicious and nutritious meal"}
        </p>
        
        <div className="grid grid-cols-2 gap-4 text-sm mb-4">
          <div>
            <span className="text-muted-foreground">Calories:</span>
            <span className="font-medium text-foreground ml-1" data-testid={`text-meal-calories-${meal.id}`}>
              {meal.totalCalories ? Math.round(parseFloat(meal.totalCalories)) : 0}
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Protein:</span>
            <span className="font-medium text-foreground ml-1" data-testid={`text-meal-protein-${meal.id}`}>
              {meal.totalProtein ? Math.round(parseFloat(meal.totalProtein)) : 0}g
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Carbs:</span>
            <span className="font-medium text-foreground ml-1" data-testid={`text-meal-carbs-${meal.id}`}>
              {meal.totalCarbs ? Math.round(parseFloat(meal.totalCarbs)) : 0}g
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Fat:</span>
            <span className="font-medium text-foreground ml-1" data-testid={`text-meal-fat-${meal.id}`}>
              {meal.totalFat ? Math.round(parseFloat(meal.totalFat)) : 0}g
            </span>
          </div>
        </div>

        {meal.dietaryTags && meal.dietaryTags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {meal.dietaryTags.slice(0, 3).map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}
        
        <Button 
          variant="outline" 
          className="w-full bg-primary/10 text-primary hover:bg-primary/20 border-primary/20"
          data-testid={`button-view-recipe-${meal.id}`}
        >
          <i className="fas fa-eye mr-2"></i>View Recipe
        </Button>
      </CardContent>
    </Card>
  );
}
