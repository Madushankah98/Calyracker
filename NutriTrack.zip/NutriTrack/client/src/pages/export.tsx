import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Export() {
  const [pdfOptions, setPdfOptions] = useState({
    includeRecipes: true,
    includeShoppingList: true,
    includeNutritionalAnalysis: false,
  });
  const [imageFormat, setImageFormat] = useState("instagram_story");
  const { toast } = useToast();

  const exportPdfMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would call a PDF generation service
      const response = await apiRequest("POST", "/api/export/pdf", pdfOptions);
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'meal-plan.pdf';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "PDF Downloaded!",
        description: "Your meal plan has been saved as a PDF.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Unable to generate PDF. Please try again.",
        variant: "destructive",
      });
    },
  });

  const exportImageMutation = useMutation({
    mutationFn: async () => {
      // In a real implementation, this would call an image generation service
      const response = await apiRequest("POST", "/api/export/image", {
        format: imageFormat,
      });
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `meal-plan-${imageFormat}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Image Downloaded!",
        description: "Your meal plan image has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Export Failed",
        description: "Unable to generate image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const shareProgress = (platform: string) => {
    const text = "Check out my personalized nutrition plan from NutriTrack! 🌱";
    const url = window.location.origin;
    
    switch (platform) {
      case "instagram":
        toast({
          title: "Instagram Share",
          description: "Export an image first, then share it on Instagram!",
        });
        break;
      case "twitter":
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`);
        break;
      case "email":
        window.open(`mailto:?subject=My NutriTrack Meal Plan&body=${encodeURIComponent(text + "\n\n" + url)}`);
        break;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Export Your Meal Plan</h2>
        <p className="text-muted-foreground">Download and share your personalized nutrition plan</p>
      </div>

      {/* Export Options */}
      <div className="grid md:grid-cols-2 gap-8 mb-8">
        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-file-pdf text-destructive text-xl"></i>
              </div>
              <div>
                <CardTitle>PDF Export</CardTitle>
                <p className="text-sm text-muted-foreground">Complete meal plan with recipes</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-recipes"
                  checked={pdfOptions.includeRecipes}
                  onCheckedChange={(checked) =>
                    setPdfOptions(prev => ({ ...prev, includeRecipes: !!checked }))
                  }
                  data-testid="checkbox-include-recipes"
                />
                <Label htmlFor="include-recipes" className="text-sm text-foreground">
                  Include full recipes
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-shopping"
                  checked={pdfOptions.includeShoppingList}
                  onCheckedChange={(checked) =>
                    setPdfOptions(prev => ({ ...prev, includeShoppingList: !!checked }))
                  }
                  data-testid="checkbox-include-shopping"
                />
                <Label htmlFor="include-shopping" className="text-sm text-foreground">
                  Include shopping list
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="include-analysis"
                  checked={pdfOptions.includeNutritionalAnalysis}
                  onCheckedChange={(checked) =>
                    setPdfOptions(prev => ({ ...prev, includeNutritionalAnalysis: !!checked }))
                  }
                  data-testid="checkbox-include-analysis"
                />
                <Label htmlFor="include-analysis" className="text-sm text-foreground">
                  Include nutritional analysis
                </Label>
              </div>
            </div>
            <Button
              onClick={() => exportPdfMutation.mutate()}
              disabled={exportPdfMutation.isPending}
              className="w-full bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-download-pdf"
            >
              {exportPdfMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                  Generating PDF...
                </>
              ) : (
                <>
                  <i className="fas fa-download mr-2"></i>Download PDF
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card className="transition-all duration-200 hover:shadow-lg">
          <CardHeader>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-chart-2/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-image text-chart-2 text-xl"></i>
              </div>
              <div>
                <CardTitle>Image Export</CardTitle>
                <p className="text-sm text-muted-foreground">Visual snapshot for sharing</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <RadioGroup value={imageFormat} onValueChange={setImageFormat}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="instagram_story" id="instagram_story" />
                <Label htmlFor="instagram_story" className="text-sm text-foreground">
                  Instagram Story (1080x1920)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="square_post" id="square_post" />
                <Label htmlFor="square_post" className="text-sm text-foreground">
                  Square Post (1080x1080)
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="desktop_wallpaper" id="desktop_wallpaper" />
                <Label htmlFor="desktop_wallpaper" className="text-sm text-foreground">
                  Desktop Wallpaper (1920x1080)
                </Label>
              </div>
            </RadioGroup>
            <Button
              onClick={() => exportImageMutation.mutate()}
              disabled={exportImageMutation.isPending}
              className="w-full bg-chart-2 text-white hover:bg-chart-2/90"
              data-testid="button-generate-image"
            >
              {exportImageMutation.isPending ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                  Generating Image...
                </>
              ) : (
                <>
                  <i className="fas fa-camera mr-2"></i>Generate Image
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Preview Section */}
      <Card className="transition-all duration-200">
        <CardHeader>
          <CardTitle>Export Preview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-muted/50 rounded-lg p-6 border-2 border-dashed border-border">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-chart-2 rounded-xl mx-auto mb-4 flex items-center justify-center">
                <i className="fas fa-leaf text-white text-2xl"></i>
              </div>
              <h4 className="font-bold text-foreground text-lg mb-2">NutriTrack Meal Plan</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Week of {new Date().toLocaleDateString()}
              </p>
              
              <div className="grid grid-cols-3 gap-4 text-center mb-4">
                <div className="p-3 bg-card rounded-lg border border-border">
                  <div className="font-bold text-foreground" data-testid="text-preview-calories">1,785</div>
                  <div className="text-xs text-muted-foreground">Avg Calories</div>
                </div>
                <div className="p-3 bg-card rounded-lg border border-border">
                  <div className="font-bold text-foreground" data-testid="text-preview-protein">134g</div>
                  <div className="text-xs text-muted-foreground">Avg Protein</div>
                </div>
                <div className="p-3 bg-card rounded-lg border border-border">
                  <div className="font-bold text-foreground" data-testid="text-preview-target">-0.5kg</div>
                  <div className="text-xs text-muted-foreground">Target Loss</div>
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                Generated on {new Date().toLocaleDateString()} by NutriTrack
              </div>
            </div>
          </div>
          
          <Card className="mt-6 bg-accent/50 border-accent">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <i className="fas fa-lightbulb text-chart-3 mt-1"></i>
                <div>
                  <div className="font-medium text-foreground text-sm">Pro Tip</div>
                  <div className="text-xs text-muted-foreground">
                    Share your progress on social media to stay motivated and inspire others on their nutrition journey!
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Sharing Options */}
      <Card>
        <CardHeader>
          <CardTitle>Share Your Success</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-3">
            <Button
              onClick={() => shareProgress("instagram")}
              className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 text-white hover:opacity-90 transition-opacity"
              data-testid="button-share-instagram"
            >
              <i className="fab fa-instagram mb-1 block"></i>
              Instagram
            </Button>
            <Button
              onClick={() => shareProgress("twitter")}
              className="p-3 bg-blue-500 text-white hover:bg-blue-600 transition-colors"
              data-testid="button-share-twitter"
            >
              <i className="fab fa-twitter mb-1 block"></i>
              Twitter
            </Button>
            <Button
              onClick={() => shareProgress("email")}
              className="p-3 bg-gray-600 text-white hover:bg-gray-700 transition-colors"
              data-testid="button-share-email"
            >
              <i className="fas fa-envelope mb-1 block"></i>
              Email
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
