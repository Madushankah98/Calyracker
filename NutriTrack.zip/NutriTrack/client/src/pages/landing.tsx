import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-chart-2/5">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center space-x-2 mb-8">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
              <i className="fas fa-leaf text-primary-foreground text-2xl"></i>
            </div>
            <h1 className="text-4xl font-bold text-foreground">NutriTrack</h1>
          </div>
          <h2 className="text-5xl font-bold text-foreground mb-6">
            Your Personal Nutrition
            <span className="text-primary block">Journey Starts Here</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Personalized meal planning, calorie tracking, and progress analytics 
            to help you achieve your health goals with science-backed nutrition guidance.
          </p>
          <Button 
            size="lg" 
            className="text-lg px-8 py-4 rounded-xl"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login"
          >
            Start Your Journey
            <i className="fas fa-arrow-right ml-2"></i>
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <Card className="text-center border-0 shadow-lg">
            <CardHeader>
              <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-calculator text-primary text-2xl"></i>
              </div>
              <CardTitle>Smart Calculations</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Advanced BMR and TDEE calculations provide personalized calorie and macro targets based on your goals.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-0 shadow-lg">
            <CardHeader>
              <div className="w-16 h-16 bg-chart-2/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-utensils text-chart-2 text-2xl"></i>
              </div>
              <CardTitle>Dynamic Meal Plans</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Get a fresh, randomized 7-day meal plan every week that adapts to your preferences and restrictions.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center border-0 shadow-lg">
            <CardHeader>
              <div className="w-16 h-16 bg-chart-3/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-chart-line text-chart-3 text-2xl"></i>
              </div>
              <CardTitle>Visual Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                Beautiful charts and gamification features keep you motivated with streaks, achievements, and insights.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold text-foreground mb-4">
            Join thousands achieving their health goals
          </h3>
          <div className="flex justify-center space-x-8 text-muted-foreground">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">10K+</div>
              <div className="text-sm">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-chart-2">50K+</div>
              <div className="text-sm">Meals Tracked</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-chart-3">95%</div>
              <div className="text-sm">Goal Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
