import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Dashboard from "@/pages/dashboard";
import MealPlan from "@/pages/meal-plan";
import Progress from "@/pages/progress";
import Export from "@/pages/export";
import Onboarding from "@/pages/onboarding";
import { useState } from "react";

export default function Home() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: userData, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your profile...</p>
        </div>
      </div>
    );
  }

  // If user has no profile, show onboarding
  if (!userData?.profile) {
    return <Onboarding />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <Dashboard />;
      case "meals":
        return <MealPlan />;
      case "progress":
        return <Progress />;
      case "export":
        return <Export />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="max-w-6xl mx-auto p-4 pb-8">
        {renderContent()}
      </main>
    </div>
  );
}
