# NutriTrack - Personal Nutrition Management Application

## Overview

NutriTrack is a comprehensive personal nutrition management application that provides users with personalized meal planning, calorie tracking, and progress analytics. The application combines science-backed nutrition calculations with an intuitive user interface to help users achieve their health goals through structured meal planning and progress monitoring.

The system features automatic BMR/TDEE calculations, customizable meal plans, water intake tracking, weight monitoring, and achievement systems. Users can generate meal plans, export them as PDFs or social media images, and track their progress through various metrics and streaks.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built with React and TypeScript using Vite as the build tool. The application follows a modern component-based architecture with:

- **UI Framework**: React with TypeScript for type safety
- **Styling**: Tailwind CSS with custom design system variables and shadcn/ui components
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and caching
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Theme System**: Custom theme provider supporting light/dark mode with CSS variables

The frontend structure separates concerns with dedicated directories for components, pages, hooks, and utilities. The application uses a responsive design approach optimized for both desktop and mobile devices.

### Backend Architecture
The backend follows a RESTful Express.js architecture with TypeScript:

- **Framework**: Express.js with TypeScript for API endpoints
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with OpenID Connect for secure user authentication
- **Session Management**: Express sessions with PostgreSQL storage using connect-pg-simple
- **API Structure**: RESTful endpoints organized by feature domains (auth, profile, meals, logs, etc.)

The server implements middleware for logging, error handling, and authentication checks. Development and production environments are handled differently, with Vite integration for development hot reloading.

### Data Storage Solutions
The application uses PostgreSQL as the primary database with Drizzle ORM for schema management:

- **Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle migrations with version control
- **Data Models**: Comprehensive schemas for users, profiles, meals, logs, and achievements
- **Relationships**: Properly structured foreign key relationships between entities
- **Indexing**: Strategic indexes for session management and query optimization

Key data entities include user profiles with nutritional data, food items and meals, daily logs for food/water/weight/exercise, and achievement tracking systems.

### Authentication and Authorization
Authentication is handled through Replit's OpenID Connect integration:

- **Provider**: Replit Auth with OpenID Connect protocol
- **Session Storage**: Secure session management in PostgreSQL
- **User Management**: Automatic user creation and profile linking
- **Route Protection**: Middleware-based authentication checks for protected endpoints
- **Security**: HTTPS-only cookies and secure session configuration

The system supports automatic user onboarding flow and profile creation upon first authentication.

### Calculation Engine
The application implements scientifically-backed nutrition calculations:

- **BMR Calculation**: Mifflin-St Jeor equation for accurate basal metabolic rate
- **TDEE Calculation**: Activity level multipliers for total daily energy expenditure
- **Macro Targets**: Goal-based protein, carbohydrate, and fat distribution
- **Calorie Targets**: Deficit/surplus calculations based on weight goals
- **Progress Metrics**: Weight loss/gain tracking and goal progress calculations

These calculations are performed server-side and stored in user profiles for consistency.

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with WebSocket support
- **Connection Pooling**: @neondatabase/serverless for optimized database connections

### Authentication Services
- **Replit Auth**: OpenID Connect authentication provider
- **Session Storage**: PostgreSQL-backed session management

### Frontend Libraries
- **UI Components**: Radix UI primitives for accessible component foundation
- **Icons**: Font Awesome for consistent iconography
- **Date Handling**: date-fns for date manipulation and formatting
- **Charts**: Recharts for data visualization (configured but not yet implemented)

### Development Tools
- **Build System**: Vite for fast development and optimized production builds
- **Type Checking**: TypeScript compiler for static type analysis
- **CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer
- **Development Server**: Vite dev server with hot module replacement

### Deployment and Hosting
- **Platform**: Replit hosting environment
- **Asset Management**: Vite-based asset bundling and optimization
- **Environment Configuration**: Environment-based configuration for development and production

The application is designed to be deployed on Replit's hosting platform with automatic environment provisioning and database setup.