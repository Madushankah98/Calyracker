import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { insertUserProfileSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const formSchema = insertUserProfileSchema.extend({
  goalWeight: z.string().optional(),
}).omit({ userId: true, bmr: true, tdee: true, dailyCalorieTarget: true, proteinTarget: true, carbTarget: true, fatTarget: true });

export default function Onboarding() {
  const [selectedGoal, setSelectedGoal] = useState<string>("");
  const [selectedDiets, setSelectedDiets] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: 25,
      sex: "",
      height: "",
      currentWeight: "",
      goalWeight: "",
      goal: "",
      activityLevel: "",
      dietaryPreferences: [],
      allergies: [],
    },
  });

  const createProfileMutation = useMutation({
    mutationFn: async (data: z.infer<typeof formSchema>) => {
      const response = await apiRequest("POST", "/api/profile", {
        ...data,
        goal: selectedGoal,
        dietaryPreferences: selectedDiets,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Created!",
        description: "Your personalized nutrition plan is ready.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: z.infer<typeof formSchema>) => {
    createProfileMutation.mutate(data);
  };

  const toggleDiet = (diet: string) => {
    setSelectedDiets(prev => 
      prev.includes(diet) 
        ? prev.filter(d => d !== diet)
        : [...prev, diet]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-chart-2/5 p-4">
      <div className="max-w-2xl mx-auto pt-8">
        <Card className="shadow-xl border-0">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <i className="fas fa-leaf text-primary-foreground"></i>
                </div>
                <h1 className="text-2xl font-bold text-foreground">NutriTrack</h1>
              </div>
              <h2 className="text-3xl font-bold text-foreground mb-2">Welcome to NutriTrack</h2>
              <p className="text-muted-foreground">Let's personalize your nutrition journey</p>
              <div className="flex justify-center mt-4">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                </div>
              </div>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="25" 
                            {...field} 
                            data-testid="input-age"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="sex"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sex</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-sex">
                              <SelectValue placeholder="Select sex" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="height"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Height (cm)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="175" 
                            {...field} 
                            data-testid="input-height"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="currentWeight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Current Weight (kg)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="70" 
                            {...field} 
                            data-testid="input-weight"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div>
                  <FormLabel className="block text-sm font-medium text-foreground mb-4">Primary Goal</FormLabel>
                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      type="button"
                      variant={selectedGoal === "lose" ? "default" : "outline"}
                      className="p-4 h-auto flex flex-col"
                      onClick={() => setSelectedGoal("lose")}
                      data-testid="button-goal-lose"
                    >
                      <i className="fas fa-arrow-down mb-2 text-lg"></i>
                      Lose Weight
                    </Button>
                    <Button
                      type="button"
                      variant={selectedGoal === "maintain" ? "default" : "outline"}
                      className="p-4 h-auto flex flex-col"
                      onClick={() => setSelectedGoal("maintain")}
                      data-testid="button-goal-maintain"
                    >
                      <i className="fas fa-balance-scale mb-2 text-lg"></i>
                      Maintain
                    </Button>
                    <Button
                      type="button"
                      variant={selectedGoal === "gain" ? "default" : "outline"}
                      className="p-4 h-auto flex flex-col"
                      onClick={() => setSelectedGoal("gain")}
                      data-testid="button-goal-gain"
                    >
                      <i className="fas fa-arrow-up mb-2 text-lg"></i>
                      Gain Weight
                    </Button>
                  </div>
                </div>

                {selectedGoal === "lose" || selectedGoal === "gain" ? (
                  <FormField
                    control={form.control}
                    name="goalWeight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Goal Weight (kg)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="65" 
                            {...field} 
                            data-testid="input-goal-weight"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ) : null}

                <FormField
                  control={form.control}
                  name="activityLevel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Activity Level</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-activity">
                            <SelectValue placeholder="Select activity level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="sedentary">Sedentary (little to no exercise)</SelectItem>
                          <SelectItem value="lightly_active">Lightly active (light exercise 1-3 days/week)</SelectItem>
                          <SelectItem value="moderately_active">Moderately active (moderate exercise 3-5 days/week)</SelectItem>
                          <SelectItem value="very_active">Very active (hard exercise 6-7 days/week)</SelectItem>
                          <SelectItem value="extremely_active">Extremely active (very hard exercise, physical job)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel className="block text-sm font-medium text-foreground mb-4">Dietary Preferences</FormLabel>
                  <div className="flex flex-wrap gap-2">
                    {["vegetarian", "vegan", "keto", "paleo", "gluten-free"].map((diet) => (
                      <Button
                        key={diet}
                        type="button"
                        variant={selectedDiets.includes(diet) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleDiet(diet)}
                        data-testid={`button-diet-${diet}`}
                      >
                        {diet.charAt(0).toUpperCase() + diet.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>

                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full"
                  disabled={createProfileMutation.isPending || !selectedGoal}
                  data-testid="button-complete-setup"
                >
                  {createProfileMutation.isPending ? (
                    <>
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
                      Creating Profile...
                    </>
                  ) : (
                    "Complete Setup & Calculate Goals"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
