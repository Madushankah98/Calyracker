import {
  users,
  userProfiles,
  foodItems,
  meals,
  mealPlans,
  dailyMeals,
  mealIngredients,
  foodLogs,
  waterLogs,
  weightLogs,
  exerciseLogs,
  achievements,
  type User,
  type UpsertUser,
  type UserProfile,
  type InsertUserProfile,
  type FoodItem,
  type InsertFoodItem,
  type Meal,
  type InsertMeal,
  type MealPlan,
  type InsertMealPlan,
  type DailyMeal,
  type FoodLog,
  type InsertFoodLog,
  type WaterLog,
  type InsertWaterLog,
  type WeightLog,
  type InsertWeightLog,
  type ExerciseLog,
  type InsertExerciseLog,
  type Achievement,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // User profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile>;
  
  // Food items operations
  getFoodItems(): Promise<FoodItem[]>;
  getFoodItem(id: string): Promise<FoodItem | undefined>;
  createFoodItem(item: InsertFoodItem): Promise<FoodItem>;
  
  // Meals operations
  getMeals(): Promise<Meal[]>;
  getMealsByType(mealType: string): Promise<Meal[]>;
  getMealsByDietaryTags(tags: string[]): Promise<Meal[]>;
  getMeal(id: string): Promise<Meal | undefined>;
  createMeal(meal: InsertMeal): Promise<Meal>;
  
  // Meal plan operations
  getUserMealPlan(userId: string, weekStart?: string): Promise<MealPlan | undefined>;
  createMealPlan(plan: InsertMealPlan): Promise<MealPlan>;
  getDailyMeals(mealPlanId: string): Promise<DailyMeal[]>;
  createDailyMeal(mealId: string, mealPlanId: string, dayOfWeek: number, mealType: string, orderIndex?: number): Promise<DailyMeal>;
  
  // Food logging operations
  getFoodLogs(userId: string, date?: string): Promise<FoodLog[]>;
  createFoodLog(log: InsertFoodLog): Promise<FoodLog>;
  
  // Water tracking operations
  getWaterLog(userId: string, date: string): Promise<WaterLog | undefined>;
  upsertWaterLog(log: InsertWaterLog): Promise<WaterLog>;
  
  // Weight tracking operations
  getWeightLogs(userId: string, limit?: number): Promise<WeightLog[]>;
  createWeightLog(log: InsertWeightLog): Promise<WeightLog>;
  getLatestWeight(userId: string): Promise<WeightLog | undefined>;
  
  // Exercise tracking operations
  getExerciseLogs(userId: string, date?: string): Promise<ExerciseLog[]>;
  createExerciseLog(log: InsertExerciseLog): Promise<ExerciseLog>;
  
  // Achievement operations
  getUserAchievements(userId: string): Promise<Achievement[]>;
  upsertAchievement(userId: string, type: string, currentStreak: number): Promise<Achievement>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User profile operations
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId));
    return profile;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const [newProfile] = await db
      .insert(userProfiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateUserProfile(userId: string, profile: Partial<InsertUserProfile>): Promise<UserProfile> {
    const [updatedProfile] = await db
      .update(userProfiles)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return updatedProfile;
  }

  // Food items operations
  async getFoodItems(): Promise<FoodItem[]> {
    return await db.select().from(foodItems);
  }

  async getFoodItem(id: string): Promise<FoodItem | undefined> {
    const [item] = await db.select().from(foodItems).where(eq(foodItems.id, id));
    return item;
  }

  async createFoodItem(item: InsertFoodItem): Promise<FoodItem> {
    const [newItem] = await db.insert(foodItems).values(item).returning();
    return newItem;
  }

  // Meals operations
  async getMeals(): Promise<Meal[]> {
    return await db.select().from(meals);
  }

  async getMealsByType(mealType: string): Promise<Meal[]> {
    return await db.select().from(meals).where(eq(meals.mealType, mealType));
  }

  async getMealsByDietaryTags(tags: string[]): Promise<Meal[]> {
    return await db
      .select()
      .from(meals)
      .where(sql`${meals.dietaryTags} && ${tags}`);
  }

  async getMeal(id: string): Promise<Meal | undefined> {
    const [meal] = await db.select().from(meals).where(eq(meals.id, id));
    return meal;
  }

  async createMeal(meal: InsertMeal): Promise<Meal> {
    const [newMeal] = await db.insert(meals).values(meal).returning();
    return newMeal;
  }

  // Meal plan operations
  async getUserMealPlan(userId: string, weekStart?: string): Promise<MealPlan | undefined> {
    const query = db
      .select()
      .from(mealPlans)
      .where(eq(mealPlans.userId, userId));
    
    let finalQuery;
    if (weekStart) {
      finalQuery = query.where(and(eq(mealPlans.userId, userId), eq(mealPlans.weekStartDate, weekStart)));
    } else {
      finalQuery = query.where(and(eq(mealPlans.userId, userId), eq(mealPlans.isActive, true)));
    }
    
    const [plan] = await finalQuery.orderBy(desc(mealPlans.createdAt));
    return plan;
  }

  async createMealPlan(plan: InsertMealPlan): Promise<MealPlan> {
    // Deactivate existing meal plans
    await db
      .update(mealPlans)
      .set({ isActive: false })
      .where(eq(mealPlans.userId, plan.userId));
    
    const [newPlan] = await db.insert(mealPlans).values(plan).returning();
    return newPlan;
  }

  async getDailyMeals(mealPlanId: string): Promise<DailyMeal[]> {
    return await db
      .select()
      .from(dailyMeals)
      .where(eq(dailyMeals.mealPlanId, mealPlanId))
      .orderBy(dailyMeals.dayOfWeek, dailyMeals.orderIndex);
  }

  async createDailyMeal(mealId: string, mealPlanId: string, dayOfWeek: number, mealType: string, orderIndex = 0): Promise<DailyMeal> {
    const [dailyMeal] = await db
      .insert(dailyMeals)
      .values({
        mealId,
        mealPlanId,
        dayOfWeek,
        mealType,
        orderIndex,
      })
      .returning();
    return dailyMeal;
  }

  // Food logging operations
  async getFoodLogs(userId: string, date?: string): Promise<FoodLog[]> {
    const query = db.select().from(foodLogs).where(eq(foodLogs.userId, userId));
    
    let finalFoodQuery = query;
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      finalFoodQuery = query.where(
        and(
          eq(foodLogs.userId, userId),
          gte(foodLogs.loggedAt, startOfDay),
          lte(foodLogs.loggedAt, endOfDay)
        )
      );
    }
    
    return await finalFoodQuery.orderBy(desc(foodLogs.loggedAt));
  }

  async createFoodLog(log: InsertFoodLog): Promise<FoodLog> {
    const [newLog] = await db.insert(foodLogs).values(log).returning();
    return newLog;
  }

  // Water tracking operations
  async getWaterLog(userId: string, date: string): Promise<WaterLog | undefined> {
    const [log] = await db
      .select()
      .from(waterLogs)
      .where(and(eq(waterLogs.userId, userId), eq(waterLogs.date, date)));
    return log;
  }

  async upsertWaterLog(log: InsertWaterLog): Promise<WaterLog> {
    const existing = await this.getWaterLog(log.userId, log.date);
    
    if (existing) {
      const [updatedLog] = await db
        .update(waterLogs)
        .set({ glasses: log.glasses, loggedAt: new Date() })
        .where(eq(waterLogs.id, existing.id))
        .returning();
      return updatedLog;
    } else {
      const [newLog] = await db.insert(waterLogs).values(log).returning();
      return newLog;
    }
  }

  // Weight tracking operations
  async getWeightLogs(userId: string, limit = 10): Promise<WeightLog[]> {
    return await db
      .select()
      .from(weightLogs)
      .where(eq(weightLogs.userId, userId))
      .orderBy(desc(weightLogs.date))
      .limit(limit);
  }

  async createWeightLog(log: InsertWeightLog): Promise<WeightLog> {
    const [newLog] = await db.insert(weightLogs).values(log).returning();
    return newLog;
  }

  async getLatestWeight(userId: string): Promise<WeightLog | undefined> {
    const [log] = await db
      .select()
      .from(weightLogs)
      .where(eq(weightLogs.userId, userId))
      .orderBy(desc(weightLogs.date))
      .limit(1);
    return log;
  }

  // Exercise tracking operations
  async getExerciseLogs(userId: string, date?: string): Promise<ExerciseLog[]> {
    const query = db.select().from(exerciseLogs).where(eq(exerciseLogs.userId, userId));
    
    let finalExerciseQuery = query;
    if (date) {
      finalExerciseQuery = query.where(and(eq(exerciseLogs.userId, userId), eq(exerciseLogs.date, date)));
    }
    
    return await finalExerciseQuery.orderBy(desc(exerciseLogs.loggedAt));
  }

  async createExerciseLog(log: InsertExerciseLog): Promise<ExerciseLog> {
    const [newLog] = await db.insert(exerciseLogs).values(log).returning();
    return newLog;
  }

  // Achievement operations
  async getUserAchievements(userId: string): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.userId, userId));
  }

  async upsertAchievement(userId: string, type: string, currentStreak: number): Promise<Achievement> {
    const [existing] = await db
      .select()
      .from(achievements)
      .where(and(eq(achievements.userId, userId), eq(achievements.type, type)));

    if (existing) {
      const bestStreak = Math.max(existing.bestStreak || 0, currentStreak);
      const [updated] = await db
        .update(achievements)
        .set({
          currentStreak,
          bestStreak,
          lastUpdated: new Date(),
        })
        .where(eq(achievements.id, existing.id))
        .returning();
      return updated;
    } else {
      const [newAchievement] = await db
        .insert(achievements)
        .values({
          userId,
          type,
          currentStreak,
          bestStreak: currentStreak,
        })
        .returning();
      return newAchievement;
    }
  }
}

export const storage = new DatabaseStorage();
