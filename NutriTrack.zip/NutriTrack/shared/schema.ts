import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  integer,
  decimal,
  text,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles with nutrition data
export const userProfiles = pgTable("user_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  age: integer("age").notNull(),
  sex: varchar("sex", { length: 10 }).notNull(),
  height: decimal("height", { precision: 5, scale: 2 }).notNull(), // cm
  currentWeight: decimal("current_weight", { precision: 5, scale: 2 }).notNull(), // kg
  goalWeight: decimal("goal_weight", { precision: 5, scale: 2 }),
  goal: varchar("goal", { length: 20 }).notNull(), // lose, maintain, gain
  activityLevel: varchar("activity_level", { length: 50 }).notNull(),
  dietaryPreferences: text("dietary_preferences").array(), // vegetarian, vegan, etc.
  allergies: text("allergies").array(),
  bmr: decimal("bmr", { precision: 7, scale: 2 }), // calculated BMR
  tdee: decimal("tdee", { precision: 7, scale: 2 }), // calculated TDEE
  dailyCalorieTarget: decimal("daily_calorie_target", { precision: 7, scale: 2 }),
  proteinTarget: decimal("protein_target", { precision: 5, scale: 2 }),
  carbTarget: decimal("carb_target", { precision: 5, scale: 2 }),
  fatTarget: decimal("fat_target", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Food items database
export const foodItems = pgTable("food_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  caloriesPer100g: decimal("calories_per_100g", { precision: 6, scale: 2 }).notNull(),
  proteinPer100g: decimal("protein_per_100g", { precision: 5, scale: 2 }).notNull(),
  carbsPer100g: decimal("carbs_per_100g", { precision: 5, scale: 2 }).notNull(),
  fatPer100g: decimal("fat_per_100g", { precision: 5, scale: 2 }).notNull(),
  fiberPer100g: decimal("fiber_per_100g", { precision: 5, scale: 2 }),
  category: varchar("category", { length: 50 }),
  imageUrl: varchar("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Meals (recipes)
export const meals = pgTable("meals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  instructions: text("instructions"),
  prepTime: integer("prep_time"), // minutes
  cookTime: integer("cook_time"), // minutes
  servings: integer("servings").default(1),
  mealType: varchar("meal_type", { length: 20 }).notNull(), // breakfast, lunch, dinner, snack
  totalCalories: decimal("total_calories", { precision: 6, scale: 2 }),
  totalProtein: decimal("total_protein", { precision: 5, scale: 2 }),
  totalCarbs: decimal("total_carbs", { precision: 5, scale: 2 }),
  totalFat: decimal("total_fat", { precision: 5, scale: 2 }),
  dietaryTags: text("dietary_tags").array(), // vegetarian, vegan, gluten-free, etc.
  imageUrl: varchar("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Meal ingredients (junction table)
export const mealIngredients = pgTable("meal_ingredients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mealId: varchar("meal_id").notNull().references(() => meals.id, { onDelete: "cascade" }),
  foodItemId: varchar("food_item_id").notNull().references(() => foodItems.id),
  quantity: decimal("quantity", { precision: 6, scale: 2 }).notNull(), // grams
});

// User meal plans
export const mealPlans = pgTable("meal_plans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  weekStartDate: date("week_start_date").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Daily meal assignments
export const dailyMeals = pgTable("daily_meals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  mealPlanId: varchar("meal_plan_id").notNull().references(() => mealPlans.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(), // 0-6 (Monday-Sunday)
  mealId: varchar("meal_id").notNull().references(() => meals.id),
  mealType: varchar("meal_type", { length: 20 }).notNull(),
  orderIndex: integer("order_index").default(0),
});

// Food logging
export const foodLogs = pgTable("food_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  mealId: varchar("meal_id").references(() => meals.id),
  customFoodName: varchar("custom_food_name"),
  quantity: decimal("quantity", { precision: 6, scale: 2 }).notNull(),
  calories: decimal("calories", { precision: 6, scale: 2 }).notNull(),
  protein: decimal("protein", { precision: 5, scale: 2 }),
  carbs: decimal("carbs", { precision: 5, scale: 2 }),
  fat: decimal("fat", { precision: 5, scale: 2 }),
  loggedAt: timestamp("logged_at").defaultNow(),
  mealType: varchar("meal_type", { length: 20 }),
});

// Water tracking
export const waterLogs = pgTable("water_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  glasses: integer("glasses").notNull(),
  loggedAt: timestamp("logged_at").defaultNow(),
  date: date("date").notNull(),
});

// Weight tracking
export const weightLogs = pgTable("weight_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  weight: decimal("weight", { precision: 5, scale: 2 }).notNull(),
  loggedAt: timestamp("logged_at").defaultNow(),
  date: date("date").notNull(),
});

// Exercise tracking
export const exerciseLogs = pgTable("exercise_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  exerciseName: varchar("exercise_name").notNull(),
  duration: integer("duration"), // minutes
  caloriesBurned: decimal("calories_burned", { precision: 6, scale: 2 }),
  loggedAt: timestamp("logged_at").defaultNow(),
  date: date("date").notNull(),
});

// User achievements and streaks
export const achievements = pgTable("achievements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  type: varchar("type", { length: 50 }).notNull(), // tracking_streak, goal_streak, etc.
  currentStreak: integer("current_streak").default(0),
  bestStreak: integer("best_streak").default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  mealPlans: many(mealPlans),
  foodLogs: many(foodLogs),
  waterLogs: many(waterLogs),
  weightLogs: many(weightLogs),
  exerciseLogs: many(exerciseLogs),
  achievements: many(achievements),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
}));

export const mealsRelations = relations(meals, ({ many }) => ({
  ingredients: many(mealIngredients),
  dailyMeals: many(dailyMeals),
  foodLogs: many(foodLogs),
}));

export const mealIngredientsRelations = relations(mealIngredients, ({ one }) => ({
  meal: one(meals, {
    fields: [mealIngredients.mealId],
    references: [meals.id],
  }),
  foodItem: one(foodItems, {
    fields: [mealIngredients.foodItemId],
    references: [foodItems.id],
  }),
}));

export const mealPlansRelations = relations(mealPlans, ({ one, many }) => ({
  user: one(users, {
    fields: [mealPlans.userId],
    references: [users.id],
  }),
  dailyMeals: many(dailyMeals),
}));

export const dailyMealsRelations = relations(dailyMeals, ({ one }) => ({
  mealPlan: one(mealPlans, {
    fields: [dailyMeals.mealPlanId],
    references: [mealPlans.id],
  }),
  meal: one(meals, {
    fields: [dailyMeals.mealId],
    references: [meals.id],
  }),
}));

// Insert schemas
export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFoodItemSchema = createInsertSchema(foodItems).omit({
  id: true,
  createdAt: true,
});

export const insertMealSchema = createInsertSchema(meals).omit({
  id: true,
  createdAt: true,
});

export const insertMealPlanSchema = createInsertSchema(mealPlans).omit({
  id: true,
  createdAt: true,
});

export const insertFoodLogSchema = createInsertSchema(foodLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertWaterLogSchema = createInsertSchema(waterLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertWeightLogSchema = createInsertSchema(weightLogs).omit({
  id: true,
  loggedAt: true,
});

export const insertExerciseLogSchema = createInsertSchema(exerciseLogs).omit({
  id: true,
  loggedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type FoodItem = typeof foodItems.$inferSelect;
export type InsertFoodItem = z.infer<typeof insertFoodItemSchema>;
export type Meal = typeof meals.$inferSelect;
export type InsertMeal = z.infer<typeof insertMealSchema>;
export type MealPlan = typeof mealPlans.$inferSelect;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type DailyMeal = typeof dailyMeals.$inferSelect;
export type FoodLog = typeof foodLogs.$inferSelect;
export type InsertFoodLog = z.infer<typeof insertFoodLogSchema>;
export type WaterLog = typeof waterLogs.$inferSelect;
export type InsertWaterLog = z.infer<typeof insertWaterLogSchema>;
export type WeightLog = typeof weightLogs.$inferSelect;
export type InsertWeightLog = z.infer<typeof insertWeightLogSchema>;
export type ExerciseLog = typeof exerciseLogs.$inferSelect;
export type InsertExerciseLog = z.infer<typeof insertExerciseLogSchema>;
export type Achievement = typeof achievements.$inferSelect;
